package artifactory.test;

/**
 * Hello world!
 */
public class Project {
    public static void main(String[] args) {
        new Project();
        System.out.println("Hello World!");
    }
}
